"""T1 BAG-N swap (COMBO16): equal mean of all listed FTA members (seeds 0-3: 2 rounds; 4,5: 3 rounds; 6: 3 rounds no holdout). Base = COMBO15 (LB 0.86944).
T1 BAG swap: start from the exact base file (BASE_KERNEL/BASE_FILE); Task 1 rows = mean of T1 v11 FTA (seed 0) and
T1 v12 FTA (seed 1, different transductive hidden rounds and row subsample). Queue and Task 4 rows untouched."""
import glob, numpy as np, pandas as pd
BASE_KERNEL, BASE_FILE, OUT_NAME = 'tfb-combo15', 'submission_COMBO15.csv', 'COMBO16'
MEMBERS = ('tfb-t1v11', 'tfb-t1v12', 'tfb-t1v12s2', 'tfb-t1v12s3', 'tfb-t1v12s4', 'tfb-t1v12s5', 'tfb-t1v12s6', 'tfb-t1v12s7')
REL = glob.glob('/kaggle/input/**/kaggle_public', recursive=True)[0]
base = pd.read_csv(glob.glob(f'/kaggle/input/**/{BASE_KERNEL}/**/{BASE_FILE}', recursive=True)[0])
key = pd.read_csv(f'{REL}/submission_key.csv', dtype=str)
ks = key[key.task == 'state'][['submission_id', 'panel', 'timestamp', 'station_id', 'link_id', 'mask_regime']].copy()
ks['timestamp'] = pd.to_datetime(ks.timestamp, utc=True)
iss = (base.task == 'state').to_numpy(); sid = base.loc[iss, 'submission_id'].to_numpy()


def load(kernels, fname):
    st = pd.concat([pd.read_csv(glob.glob(f'/kaggle/input/**/{k}/**/{fname}', recursive=True)[0], dtype={'station_id': str, 'link_id': str})
                    for k in kernels], ignore_index=True)
    st['timestamp'] = pd.to_datetime(st.timestamp, utc=True)
    m = ks.merge(st, on=['panel', 'timestamp', 'station_id', 'link_id', 'mask_regime'], how='left', validate='one_to_one')
    assert m.speed_kmh.notna().all() and m.flow_vph.notna().all(), 'unmatched state keys'
    idx = m.submission_id.astype('int64').to_numpy()
    return (pd.Series(m.speed_kmh.to_numpy(), index=idx).reindex(sid).to_numpy(),
            pd.Series(m.flow_vph.to_numpy(), index=idx).reindex(sid).to_numpy())


M = [load((f'{k}a', f'{k}b'), 'state_submission_FTA.csv') for k in MEMBERS]
print('members', len(M), MEMBERS)
v0, q0 = M[0]; v1, q1 = M[1]
print('CONTROL: base T1 rows vs mean(first 4 members) rms speed (expect ~0)', round(float(np.sqrt(np.mean((base.loc[iss, 'speed_kmh'].to_numpy() - np.mean([m[0] for m in M[:4]], 0)) ** 2))), 4))
for i, (vv, qq) in enumerate(M):
    print('member', MEMBERS[i], 'rms speed vs bag', round(float(np.sqrt(np.mean((vv - np.mean([m[0] for m in M], 0)) ** 2))), 3))
print('member disagreement rms speed', round(float(np.sqrt(np.mean((v0 - v1) ** 2))), 3), 'flow', round(float(np.sqrt(np.mean((q0 - q1) ** 2))), 2))
out = base.copy()
out.loc[iss, 'speed_kmh'] = np.mean([m[0] for m in M], 0); out.loc[iss, 'flow_vph'] = np.mean([m[1] for m in M], 0)
isq = (base.task == 'queue').to_numpy()
assert (out.loc[isq, 'queue_pred'].to_numpy() == base.loc[isq, 'queue_pred'].to_numpy()).all()
sample = pd.read_csv(f'{REL}/sample_submission.csv', usecols=['submission_id']).submission_id.to_numpy()
assert len(out) == len(sample) and (out.submission_id.to_numpy() == sample).all()
assert np.isfinite(out[['speed_kmh', 'flow_vph', 'queue_pred', 'path_flow']].to_numpy()).all()
assert (out[['speed_kmh', 'flow_vph', 'path_flow']] >= 0).all().all()
out['queue_pred'] = out.queue_pred.astype(int)
out.to_csv(f'/kaggle/working/submission_{OUT_NAME}.csv', index=False)
print(OUT_NAME, 'OK', len(out))
